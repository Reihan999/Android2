package com.empty.dicodingevent.ui.finish

import com.empty.dicodingevent.ui.detail.DetailActivity
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.empty.dicodingevent.R
import com.empty.dicodingevent.databinding.FragmentFinishedBinding
import com.empty.dicodingevent.ui.MainViewModel
import com.empty.dicodingevent.ui.ReviewAdapter
import com.google.android.material.snackbar.Snackbar

class FinishedFragment : Fragment() {

    private var _binding: FragmentFinishedBinding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: MainViewModel
    private lateinit var adapter: ReviewAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFinishedBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initializeRecyclerView()

        viewModel = ViewModelProvider(this)[MainViewModel::class.java]

        viewModel.finishedEvents.observe(viewLifecycleOwner) { events ->
            adapter.submitList(events)
        }

        viewModel.isLoading.observe(viewLifecycleOwner) { loading ->
            displayLoadingIndicator(loading)
        }

        viewModel.errorMessage.observe(viewLifecycleOwner) { message ->
            message?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
            }
        }
    }

    private fun initializeRecyclerView() {
        adapter = ReviewAdapter(requireContext()) { selectedEvent ->
            val detailIntent = Intent(requireContext(), DetailActivity::class.java).apply {
                putExtra("event", selectedEvent)
            }
            startActivity(detailIntent)
        }

        binding.recycleApiFinish.layoutManager = LinearLayoutManager(context)
        binding.recycleApiFinish.adapter = adapter
    }

    private fun displayLoadingIndicator(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

